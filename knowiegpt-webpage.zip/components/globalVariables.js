// >> Variables
const getVariable = {
	['texts']: {
		pageTitle: 'KnowieGTX',
		pageDesc: '',
		pageImage: '',
		pageLink: '',
	},

	['colors']: {
		pageMainColor: '#5342C7',
	},
};

export default getVariable;
